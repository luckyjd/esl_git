<?php

/**
 * Header image, Custom background and Custom style are included in the theme framework.
 *
 * We don't need this any more!
 */

add_theme_support( 'custom-header' );
add_theme_support( 'custom-background' );
add_editor_style();